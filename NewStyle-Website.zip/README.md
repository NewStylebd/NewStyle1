# New Style — Fixed Website

## What was fixed
- Removed the accidentally duplicated second HTML document.
- Kept the complete Home, Shop, Cart and Track Order flow.
- Upgraded checkout with Bangladesh Division → District → Upazila selection.
- Added customer note field.
- Added Bangladesh mobile-number validation.
- Added order-submit loading state and clearer success/error messages.
- Preserved the existing Supabase product/order integration.

## Important
This site uses the Supabase project already present in the original file. The browser can use a Supabase publishable/anon key, but your Supabase database must have the correct Row Level Security (RLS) policies for `products` and `orders`.

Open `index.html` in a browser or deploy the folder to a static host.
